<?php $__env->startSection('content'); ?>
<section class="py-4">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col col-lg-6">
                <h1 class="color fs-h1">Lorem Ipsum</h1>
                <p class="w-75">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <button class="btn btn-fill">Learn more</button>
            </div>
            <div class="col col-lg-6 p-0">
                <img src="<?php echo e(url('public/img/home.png')); ?>" alt="image" style="height: 100%;width: 100%;">
            </div>
        </div>
    </div>
</section>
<section>
    <h1 class="color text-center my-5">
        Services
    </h1>
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col col-lg-4">
                <div class="card">
                    
                    <div class="card-body">
                        <img src="<?php echo e(url('public/img/edit.png')); ?>" alt="..." width="50">
                        <h4 class="card-title color">Lorem Ipsum</h4>

                            <p class="card-text">Some quick example text to build on the card title and make up
                                the bulk of
                                the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e(url('public/img/edit.png')); ?>" alt="..." width="50">
                        <h4 class="card-title color">Lorem Ipsum</h4>

                            <p class="card-text">Some quick example text to build on the card title and make up
                                the bulk of
                                the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e(url('public/img/edit.png')); ?>" alt="..." width="50">
                        <h4 class="card-title color">Lorem Ipsum</h4>

                            <p class="card-text">Some quick example text to build on the card title and make up
                                the bulk of
                                the card's content.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="mt-5">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-lg-12 text-center">
                <h1 class="color text-center">
                    Lorem Ipsum
                </h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                    been the industry's standard dummy text ever since the 1500s, when an unknown printer took a
                    galley of type and scrambled it to make a type specimen book.</p>
            </div>
        </div>
    </div>
</section>
<section class="mt-5">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col col-lg-5 p-0">
                <img src="<?php echo e(url('public/img/home.png')); ?>" alt="image" style="height: 100%;width: 100%;border: 6px solid #007C45;">
            </div>

            <div class="col col-lg-7 px-5">
                <h1 class="color">Lorem Ipsum</h1>
                <p class="w-75">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                    Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a type specimen book.</p>
                <button class="btn btn-fill">Learn more</button>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container-fluid">
        <div class="row align-items-center mt-5">
            <div class="col col-lg-5 p-0">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <span class="d-flex">
                            <img src="<?php echo e(url('public/img/login.jpg')); ?>" width="50" height="50" style="margin-right: 10px;"
                                class="rounded-circle">
                            <input type="text" class="form-control rounded-pill" placeholder="Add comments...">
                        </span>
                    </div>
                </div>
            </div>

        </div>
        <div class="row align-items-center mt-5">
            <div class="col col-lg-5 p-0">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <span class="d-flex">
                            <img src="<?php echo e(url('public/img/login.jpg')); ?>" width="50" height="50" style="margin-right: 10px;"
                                class="rounded-circle">
                            <div class="card rounded text-white" style="background-color: #007C45;">
                                <div class="card-body">
                                    <h4 class="card-title">Lorem Ipsum</h4>

                                        <p class="card-text">Some quick example text to build on the card title
                                            and make
                                            up
                                            the bulk of
                                            the card's content.</p>
                                </div>
                            </div>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nis\resources\views/welcome.blade.php ENDPATH**/ ?>