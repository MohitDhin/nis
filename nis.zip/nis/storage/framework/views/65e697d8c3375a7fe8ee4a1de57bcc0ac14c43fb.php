<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <link href="<?php echo e(url('public/css/style.css')); ?>" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(url('public/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>

<body>
    <div class="">
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-white effect1">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="<?php echo e(url('public/img/logo.png')); ?>" width="200" alt="logo image"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Media Center</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Contact Us</a>
                            </li>
                        </ul>
                        <form class="d-flex">
                            <button class="btn btn-out">Login</button>
                            <button class="btn btn-fill">Sign Up</button>
                        </form>
                    </div>
                </div>
            </nav>
        </header>
        <div class="main">
             <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer class="text-center mt-5 pt-5 pb-2 text-white footer-bg">
            <a class="navbar-brand" href="#"><img src="<?php echo e(url('public/img/logo.png')); ?>" width="200" alt="logo image"></a>
            <p class="mt-5">Info Support<br>Term of Use Privacy Policy<br>Copyright © 2022 Nigeria Immigration Service</p>
        </footer>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\nis\resources\views/layout/app.blade.php ENDPATH**/ ?>